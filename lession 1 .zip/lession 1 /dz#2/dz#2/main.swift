import Foundation

let a = 7.0
let b = 9.0

let c  = (sqrt(a) + sqrt(b))

let S = 0.5*a*b
let P = a + b + c
print( "гипотенуза = \(c)" )
print( " площадь = \(S) ")
print( " периметр = \(P) ")

